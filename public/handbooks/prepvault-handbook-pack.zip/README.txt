PrepVault emergency handbooks

Extract all files, then open OPEN-ME.html or any PDF. No internet is needed to read the PDFs. Original publisher links need a connection.

For personal, noncommercial use. Publisher licenses apply; see sources.json and the notices inside each unchanged PDF. No publisher endorses PrepVault. Surgery and clinical manuals require professional training. For urgent care, contact local emergency services. Reference editions can become outdated.
